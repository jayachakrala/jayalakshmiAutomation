package com.screenfunctions;

public class Admin_Page {

}
